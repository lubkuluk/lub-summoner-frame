import "./js/custom-event-steps-LSF.js";
sc.COMBAT_CONDITION.OWNED_BY_PLAYER = ig.Class.extend({
        value: null,
        _wm: new ig.Config({
            attributes: {}
        }),
        check: function (a) {
    var root = a.getCombatantRoot();
    return root && root.ownerEnemy && root.ownerEnemy.isPlayer;
}

    });
sc.ItemConsumption.inject({
        getAction: function (b) {
            var a = sc.inventory.getItem(b).useSpeed || sc.STAT_USE_SPEED.NORMAL,
            d = sc.inventory.getItem(b).foodSprite || "SANDWICH",
            c = "itemEatFast",
            e = 1,
            f = 1.2;
            if (a == sc.STAT_USE_SPEED.SLOW) {
                c = "itemEatSlow";
                e = 0.6
            } else if (a == sc.STAT_USE_SPEED.FAST) {
                c = "itemEatFastest";
                f = 0.8
            }
            return this.createAction([{
                        type: "START_ITEM_CONSUME"
                    }, {
                        type: "FOCUS_CAMERA",
                        speed: f,
                        transition: "EASE_IN_OUT",
                        zoom: 1.5
                    }, {
                        type: "SET_FACE",
                        face: "SOUTH"
                    }, {
                        type: "SHOW_FOOD_ICON",
                        icon: d
                    }, {
                        type: "SHOW_ANIMATION",
                        anim: "itemFetch",
                        wait: true
                    }, {
                        type: "SHOW_ANIMATION",
                        anim: "itemHold"
                    }, {
                        type: "WAIT",
                        time: 0.2
                    },
                    {
                        type: "IF",
                        condition: "player.entity.name == 'Starcaller1'",
                        withElse: true,
                        thenStep: [
                            {
                                type: "PLAY_SOUND",
                                sound: "media/sound/mc-gulp-new.ogg",
                                volume: 1,
                                speed: e
                            }
                        ],
                        elseStep: [
                            {
                                type: "PLAY_SOUND",
                                sound: "media/sound/move/eat.ogg",
                                volume: 1,
                                speed: e
                            }
                        ]
                    }, {
                        type: "CHANGE_FOOD_ICON",
                        state: "BUBBLE"
                    }, {
                        type: "SHOW_ANIMATION",
                        anim: c,
                        wait: true
                    }, {
                        type: "CHANGE_FOOD_ICON",
                        state: "DONE"
                    }, {
                        type: "CONSUME_ITEM",
                        item: b
                    }, {
                        type: "SHOW_ANIMATION",
                        anim: "itemEffect"
                    }, {
                        type: "WAIT",
                        time: 0.4
                    }
                ])
        }
    });
sc.PvpModel.inject({
        observers: [],
        state: 0,
        round: 0,
        winPoints: 0,
        points: {},
        enemies: [],
        allies: [], // New array for allies
        lastWinParty: null,
        blocking: false,
        roundGui: null,
        init: function () {
            this.parent("PvP");
            ig.vars.registerVarAccessor("pvp", this, "VarPvpEditor")
        },
        start: function (b, a, allies) { // Added allies parameter
            this.state = 1;
            this.round = 0;
            this.winPoints = b;
            this.points[sc.COMBATANT_PARTY.PLAYER] = 0;
            this.points[sc.COMBATANT_PARTY.ENEMY] = 0;
            this.enemies = a;
            this.allies = allies || []; // Initialize allies array
            sc.Model.notifyObserver(this,
                sc.PVP_MESSAGE.STARTED, null);
            sc.model.setCombatMode(true, true)
        },
        getDmgFactor: function () {
            return !this.isActive() ? 1 : sc.model.player.hasItem(410) ? 0.2 : sc.model.player.hasItem(223) ? 0.25 : sc.model.player.hasItem(225) ? 0.33 : 0.5
        },
        isActive: function () {
            return this.state != 0
        },
        isKillHit: function () {
            return this.state == 3
        },
        isBrake: function () {
            return this.state == 4
        },
        isFinished: function () {
            return this.state == 5
        },
        isOver: function () {
            return this.points[sc.COMBATANT_PARTY.PLAYER] == this.winPoints || this.points[sc.COMBATANT_PARTY.ENEMY] ==
            this.winPoints
        },
        isCombatantInPvP: function (b) {
            return !this.isActive() ? false : b.party == sc.COMBATANT_PARTY.PLAYER || this.allies.indexOf(b) != -1 ? true : this.enemies.indexOf(b) != -1
        },
        onPvpCombatantDefeat: function (b) {
            if (!this.isActive())
                return false;
        
            if (b.party == sc.COMBATANT_PARTY.PLAYER || this.allies.indexOf(b) != -1) {
                // Check if dualPvp is active
                if (ig.vars.get("tmp.dualPvp")) {
                    if (ig.vars.get("tmp.youHandleThePvpLogicYourselfWhileThisConditionIsActiveSoThisConditionIsHereMerelyToBlockYou"))
                        return this.showKO(sc.COMBATANT_PARTY.ENEMY);
                } else {
                    // Default behavior: declare defeat if player's party is defeated
                    if (sc.party.isDefeated())
                        return this.showKO(sc.COMBATANT_PARTY.ENEMY);
                }
            } else {
                if (this.enemies.indexOf(b) == -1)
                    return false;
        
                var allEnemiesDefeated = true;
                for (var i = this.enemies.length; i--; ) {
                    if (!this.enemies[i].isDefeated()) {
                        allEnemiesDefeated = false;
                        break;
                    }
                }
        
                if (allEnemiesDefeated)
                    return this.showKO(sc.COMBATANT_PARTY.PLAYER);
            }
        },
        releaseBlocking: function () {
            this.blocking = false
        },
        showKO: function (b) {
            var a = ++this.points[b];
            this.lastWinParty = b;
            if (sc.arena.active) {
                sc.arena.stopTimers();
                sc.arena.onPvpRoundFinished(this.lastWinParty)
            }
            this.state = 3;
            ig.game.varsChangedDeferred();
            b = new sc.PvpKoGui;
            ig.gui.addGuiElement(b);
            return sc.DRAMATIC_EFFECT[a == this.winPoints ? "PVP_FINAL_KO" : "PVP_KO"]
        },
        onPostKO: function (b) {
            var a = b == sc.COMBATANT_PARTY.ENEMY ? 1 : 0.5,
            b = b == sc.COMBATANT_PARTY.ENEMY ? 0.5 : 1;
            ig.game.playerEntity.regenPvp(a);
            for (var d = sc.party.getPartySize(); d--; )
                sc.party.getPartyMemberEntityByIndex(d).regenPvp(a);
            for (d = this.allies.length; d--; ) // Allies regenerate health
                this.allies[d].regenPvp(a);
            for (d = this.enemies.length; d--; )
                this.enemies[d].regenPvp(b);
            this.state = this.isOver() ? 5 : 4;
            ig.game.varsChangedDeferred()
        },
        startNextRound: function (b) {
            this.round = this.round + 1;
            this.roundGui = new sc.PvpRoundGui(this.round, b);
            ig.gui.addGuiElement(this.roundGui);
            this.blocking = true
        },
        finalizeRoundStart: function () {
            this.state = 2;
            if (this.roundGui) {
                this.roundGui.remove();
                this.roundGui = null
            }
            for (var b = 0; b < this.enemies.length; ++b)
                this.enemies[b].setTarget(ig.game.playerEntity, true);
            sc.arena.active && sc.arena.resumeTimers();
            ig.game.varsChangedDeferred();
            this.releaseBlocking()
        },
        stop: function () {
            for (var b = this.enemies.length, a = this.points[sc.COMBATANT_PARTY.PLAYER] == this.winPoints && this.points[sc.COMBATANT_PARTY.ENEMY] == 0; b--; ) {
                this.enemies[b].onPvpEnd(this.lastWinParty == sc.COMBATANT_PARTY.PLAYER);
                a && sc.stats.addMap("pvp", "flawlessWin-" + this.enemies[b].enemyName, 1)
            }
            this.state = 0;
            this.enemies.length = 0;
            this.allies.length = 0; // Clear allies array
            sc.Model.notifyObserver(this, sc.PVP_MESSAGE.STOPPED, null);
            sc.model.setCombatMode(false, true)
        },
        onVarAccess: function (b, a) {
            if (a[0] ==
                "pvp")
                switch (a[1]) {
                case "active":
                    return this.state != 0;
                case "brake":
                    return this.state == 4;
                case "killHit":
                    return this.state == 3;
                case "finalHit":
                    return this.state == 3 && this.isOver();
                case "finished":
                    return this.state == 5;
                case "round":
                    return this.round;
                case "lastWinPlayer":
                    return this.lastWinParty == sc.COMBATANT_PARTY.PLAYER;
                case "playerPoints":
                    return this.points[sc.COMBATANT_PARTY.PLAYER];
                case "enemyPoints":
                    return this.points[sc.COMBATANT_PARTY.ENEMY]
                }
            throw Error("Unsupported var access path: " + b);
        },
        onPostUpdate: function () {
            if (this.state ==
                3) {
                var b = true;
                ig.game.playerEntity.dying != sc.DYING_STATE.DYING && (b = false);
                for (var a = sc.party.getPartySize(); a--; )
                    sc.party.getPartyMemberEntityByIndex(a).dying || (b = false);
                for (a = this.allies.length; a--; ) // Check dying state for allies
                    this.allies[a].dying != sc.DYING_STATE.DYING && (b = false);
                for (var d = true, a = this.enemies.length; a--; )
                    this.enemies[a].dying != sc.DYING_STATE.DYING && (d = false);
                if (b || d)
                    this.onPostKO(b ? sc.COMBATANT_PARTY.ENEMY : sc.COMBATANT_PARTY.PLAYER)
            }
        },
        onReset: function () {
            this.state = 0;
            sc.Model.notifyObserver(this, sc.PVP_MESSAGE.STOPPED, null);
            sc.model.setCombatMode(false, true)
        }
});
sc.Combat.inject ({ 
        getEnemyTarget: function () {
            if (sc.party.getStrategy("BEHAVIOUR").onlyTargetPlayer)
                return ig.game.playerEntity;
        
            var a = [ig.game.playerEntity];
            var d, e;
        
            // Add enemies in the player's combatant party as possible targets
            d = this.getActiveCombatants(sc.COMBATANT_PARTY.PLAYER, true);
            for (e = d.length; e--; ) {
                this._addPartyMember(a, d[e], ig.game.playerEntity, sc.party.ai.targeting > 0);
            }
        
            // Add enemy combatants as possible targets
            for (var b = 0; b < sc.party.currentParty.length; ++b) {
                d = this.getActiveCombatants(sc.COMBATANT_PARTY.ENEMY, true);
                for (e = d.length; e--; ) {
                    this._addPartyMember(a, sc.party.getPartyMemberEntityByIndex(b), d[e], sc.party.ai.targeting > 0);
                }
            }
        
            if (sc.party.ai.targeting > 0 && a.length > 1 && Math.random() < sc.party.ai.targeting) {
                a.splice(0, 1);
            } else if (sc.party.ai.targeting < 0 && a.length > 1 && Math.random() < -sc.party.ai.targeting) {
                a.length = 1;
            }
        
            return a[Math.floor(Math.random() * a.length)];
        },
        getActiveCombatantCount: function (a, b) {
            if (a == sc.COMBATANT_PARTY.PLAYER) {
                var playerCount = sc.party.getStrategy("BEHAVIOUR").onlyTargetPlayer ? 
                                  1 : 1 + sc.party.getPartySizeAlive(true);

                // Get the additional combatants from the player's party that are technically enemies
                var additionalCombatants = this.getActiveCombatants(sc.COMBATANT_PARTY.PLAYER, true).length;

                // Return the total count
                return playerCount + additionalCombatants;
            }
            
            for (var c = this.activeCombatants[a], d = 0, e = c.length; e--; ) {
                b && c[e].enemyName != b || c[e].aggression != sc.ENEMY_AGGRESSION.PEACEFUL && d++;
            }
            return d
        },
        gatherCollaborators: function (a, b, c, d, e, f) {
            var combatants = this.activeCombatants[sc.COMBATANT_PARTY.ENEMY];
            var playerCombatants = this.activeCombatants[sc.COMBATANT_PARTY.PLAYER];
            var allCombatants = combatants.concat(playerCombatants); // Combine enemy and player combatants
        
            for (var h = allCombatants.length, e = e || d, i = 0; h--; ) {
                var j = allCombatants[h];
                if (f || !j.hasStun()) {
                    if (!j.params || !j.params.defeated) {
                        j.params && j.params.isLocked() && j.params.clearLock();
                        // Check if collabReady is a function before calling it
                        if (typeof j.collabReady === 'function' && !j.collaboration && j.collabReady(b) && a.addParticipant(j, b, c)) {
                            i++;
                            if (i == e) return true;
                        }
                    }
                }
            }
            return i >= d;
        },
        getPlayerTargetVar: function (a) {
            var b = ig.game.playerEntity.combatStats.lastTarget,
                c = sc.party.getStrategy("TARGET");
                
            // If the player has a target and the party member strategy is to target
            if (c.same && b && !b.isDefeated() && !b._killed) {
                return b;
            }
            
            // If the above condition is not met, select a random enemy in combat
            var d = this.getActiveCombatants(sc.COMBATANT_PARTY.ENEMY, true),
                e = d.length;
                
            // Return a random enemy from the list
            return d[Math.floor(Math.random() * e)];
        },
});
sc.EnemyType.inject ({
    updateTarget: function (a) {
            if (a.target) {
                if (!sc.model.isForceCombat()) {
                    var c = a.distanceTo(a.target);
                    a.targetLoseTimer = c > this.targetDetect.loseDistance ? a.targetLoseTimer + ig.system.tick : 0;
                    a.targetLoseTimer >= this.targetDetect.loseTime && a.setTarget(null);
                }
            } else if (ig.game.playerEntity) {
                var b = ig.game.playerEntity,
                    c = a.distanceTo(b),
                    d = Math.abs(a.coll.pos.z - b.coll.pos.z);
        
                if (c < this.targetDetect.detectDistance && (!this.targetDetect.detectZDelta || d < this.targetDetect.detectZDelta)) {
                    if (a.party == sc.COMBATANT_PARTY.PLAYER) {
                        // Use getPlayerTarget if the enemy is from the player's combat party
                        this.reselectTarget(a, true, false, false); // Adjust parameters as needed
                    } else {
                        this.targetDetect.onDistance ? this.assignTarget(a, b, true) : this.targetDetect.onCloseBattle && b.targetedBy.length > 0 && this.assignTarget(a, b, true);
                    }
                }
            }
        },
        reselectTarget: function (a, b, c, d) {
            var e;
            if (a.party == sc.COMBATANT_PARTY.PLAYER) {
                // Use getPlayerTarget if the enemy is from the player's combat party
                e = sc.combat.getPlayerTargetVar(a);
            } else {
                e = sc.combat.getEnemyTarget(a);
            }
            e && this.assignTarget(a, e, b, c, d);
        },
});


ig.module("game.feature.combat.entities.lsf-enemy").requires("game.feature.combat.entities.combatant", "game.feature.combat.model.enemy-type", "game.feature.combat.model.enemy-annotation", "game.feature.new-game.new-game-model").defines(function () {
    Vec2.create();
    var b = {
        damagingEntity: null,
        attackInfo: null,
        partEntity: null,
        damageResult: null,
        shielded: false,
        hpBroken: null,
        killed: false,
        weakness: false,
        dramaticEffect: null
    };
    sc.ENEMY_HP_BAR = {
        AUTO: 0,
        VISIBLE: 1,
        HIDDEN: 2
    };
    sc.ENEMY_BOOSTER_STATE = {
        NONE: 0,
        BOOSTABLE: 1,
        BOOSTED: 2
    };
    ig.ENTITY.Ally = ig.ENTITY.Combatant.extend({
        party: sc.COMBATANT_PARTY.PLAYER,
        aggression: sc.ENEMY_AGGRESSION.THREAT,
        enemyName: null,
        enemyType: null,
        enemyGroup: null,
        defeatVarIncrease: null,
        enemyTypeInitialized: false,
        dropHealOrb: 0,
        hpAttached: {
            enemy: null,
            value: 0
        },
        spawnPoint: Vec3.create(),
        currentState: null,
        postStun: {
            choice: null,
            collab: null
        },
        nextState: null,
        nextTimerChange: null,
        stateTimers: {},
        trackers: {},
        deferredPerformedConds: [],
        targetLoseTimer: 0,
        reactions: {
            enabled: [],
            current: null,
            running: null,
            restartAction: null
        },
        dodge: {
            count: 0,
            timer: 0,
            blocked: 0,
            counterReactTime: 0,
            counterCooldown: 0,
            counterCooldownMax: 0
        },
        annotate: {
            active: 0,
            passive: 0,
            weapon: 0,
            element: 0,
            extra: null
        },
        hpBreakReached: 0,
        lastPoICheck: null,
        targetFixed: false,
        collaboration: null,
        collabAttribs: null,
        elementModes: null,
        storedEnemies: [],
        ownerEnemy: null,
        cameraZFocus: 0,
        startEffect: null,
        targetOnSpawn: false,
        boosterState: 0,
        level: {
            override: null,
            setting: null
        },
        visibility: {
            analyzable: true,
            hpBar: sc.ENEMY_HP_BAR.AUTO
        },
        _wm: new ig.Config({
            spawnable: true,
            attributes: {
                enemyInfo: {
                    _type: "EnemyType",
                    _info: "Enemy information",
                    _popup: true
                },
                spawnCondition: {
                    _type: "VarCondition",
                    _info: "Condition for Enemy to spawn",
                    _popup: true
                },
                manualKill: {
                    _type: "VarName",
                    _info: "Instead of killing the enemy, set specified variable to true.",
                    _optional: true
                }
            },
            label: function () {
                return ""
            },
            drawBox: true,
            boxColor: "rgba(255,0,0, 0.5)"
        }),
        init: function (a, b, d, g) {
            this.parent(a, b, d, g);
            this.setSize(24, 24, 0);
            Vec3.assign(this.spawnPoint, this.coll.pos);
            if (g.enemyInfo) {
                this.enemyName = g.enemyInfo.type;
                this.enemyType = new sc.EnemyType(g.enemyInfo.type);
                this.enemyGroup = g.enemyInfo.group;
                this.currentState = g.enemyInfo.state || null;
                this.dropHealOrb = g.enemyInfo.dropHealOrb || 0;
                if (g.enemyInfo.startEffect)
                    this.startEffect = new ig.EffectHandle(g.enemyInfo.startEffect);
                if (g.enemyInfo.hideEffect)
                    this.hideAction = new ig.Action("enemyHide", [{
                                    type: "SHOW_EFFECT",
                                    effect: g.enemyInfo.hideEffect,
                                    wait: true,
                                    align: "CENTER"
                                }, {
                                    type: "HIDE"
                                }
                            ]);
                if (g.enemyInfo.varIncrease) {
                    this.defeatVarIncrease = g.enemyInfo.varIncrease;
                    ig.vars.setDefault(this.defeatVarIncrease, 0)
                }
                this.targetOnSpawn =
                    g.enemyInfo.targetOnSpawn || false;
                this.level.setting = sc.newgame.get("scale-enemies") && !g.enemyInfo.disableNoScale && !ig.vars.get("g.newgame.intro") ? sc.model.player.getParamAvgLevel(4) : g.enemyInfo.level || null;
                if (g.enemyInfo.party)
                    this.party = sc.COMBATANT_PARTY[g.enemyInfo.party];
                var a = g.enemyInfo.attribs,
                h;
                for (h in a)
                    this.setAttribute(h, a[h]);
                h = ig.ActorEntity.FACE8.SOUTH;
                g.enemyInfo.face && (h = ig.ActorEntity.FACE8[g.enemyInfo.face] || ig.ActorEntity.FACE8.NORTH);
                ig.ActorEntity.getFaceVec(h, this.face);
                if (window.wm) {
                    this._wm =
                        this._wm.copy();
                    this._wm.drawBox = false;
                    this.enemyType.initEntity(this);
                    this.initAnimations()
                }
            }
            this.manualKill = g.manualKill || null;
            this.ownerEnemy = g.ownerEnemy || null;
            this.boosterState = g.boostable ? sc.ENEMY_BOOSTER_STATE.BOOSTABLE : sc.ENEMY_BOOSTER_STATE.NONE;
            g.startAction && this.setAction(g.startAction)
        },
        setElementMode: function (a, b) {
            if (this.elementModes && this.elementModes.current != a) {
                this.params.setBaseParams(this.elementModes.modes[a], b);
                if (b)
                    ig.EffectTools.clearEffects(this, "modeAura");
                else {
                    sc.combat.showModeChange(this,
                        a);
                    sc.combat.showModeAura(this, a)
                }
                this.elementModes.current = a
            }
        },
        getQuickMenuSettings: function () {
            return {
                type: "Enemy",
                disabled: !this.params || !this.visibility.analyzable || !sc.combat.isEnemyAnalyzable(this.enemyName)
            }
        },
        connectHpToEnemies: function (a) {
            for (var b = this.params.getHpFactor() / a.length, d = a.length; d--; ) {
                var g = a[d];
                g.hpAttached.enemy = this;
                g.hpAttached.value = b
            }
        },
        setLevelOverride: function (a) {
            this.level.override = a;
            this.enemyTypeInitialized && this.enemyType.updateParams(this)
        },
        getLevel: function () {
            return this.level.override ||
            this.enemyType.level
        },
        storeEnemy: function (a) {
            this.storedEnemies.push(a)
        },
        onStoredRelease: function () {
            this.show(true);
            for (var a = 0; a < this.reactions.enabled.length; ++a) {
                var b = this.reactions.enabled[a],
                d = this.enemyType.reactions[b];
                if (d.type == "STORE_RELEASE") {
                    this.reactions.current = b;
                    d.onStoredRelease(this);
                    return true
                }
            }
        },
        onEnemyEvent: function (a, b, d) {
            for (var g = 0; g < this.reactions.enabled.length; ++g) {
                var h = this.reactions.enabled[g],
                i = this.enemyType.reactions[h];
                if (i.type == "ENEMY_EVENT" && i.checkEnemyEvent(this,
                        a, b, d)) {
                    this.reactions.current = h;
                    i.onEnemyEvent(this, this.enemyType.actions);
                    return true
                }
            }
        },
        onMagnetStart: function () {
            if (this.isDefeated())
                return false;
            if (this.onEnemyEvent(this.target, sc.COMBAT_ENEMY_EVENT.MAGNET_PULL, null)) {
                this.invincibleTimer = -1;
                this.coll.setType(ig.COLLTYPE.IGNORE);
                this.damageTimer = 1E3;
                return true
            }
        },
        onMagnetEnd: function () {
            this.damageTimer = this.invincibleTimer = 0;
            this.cancelAction()
        },
        isBoss: function () {
            return this.enemyType.boss
        },
        getHeadIdx: function () {
            return this.enemyType.headIdx
        },
        show: function (b) {
            this.parent(b);
            var d = this.currentAction;
            this.level.setting && this.setLevelOverride(1 * ig.Event.getExpressionValue(this.level.setting));
            this.enemyType.initEntity(this);
            this.initAnimations();
            if (!b) {
                this.animState.alpha = 0;
                b = this.enemyType.getAppearAction(this);
                if (d || !b)
                    this.startEffect ? this.startEffect.spawnOnTarget(this) : ig.game.effects.teleport.spawnOnTarget("showDefault", this);
                this.setAction(d || b || a)
            }
            this.targetOnSpawn && this.enemyType.reselectTarget(this, false, true, true)
        },
        onHideRequest: function () {
            this.statusGui &&
            this.statusGui.remove();
            this.statusGui = null;
            if (!this.dying) {
                ig.EffectTools.clearEffects(this);
                this.setAction(this.hideAction || d)
            }
        },
        hide: function () {
            ig.EffectTools.clearEffects(this);
            this.parent()
        },
        onKill: function (a) {
            this.parent(a);
            a || this._delegateDamage();
            this.startEffect && this.startEffect.clearCached();
            this.hideAction && this.hideAction.clearCached();
            this.enemyType.onEntityKill(this);
            this.enemyType.decreaseRef()
        },
        regenPvp: function (a) {
            this.parent(a);
            this.setElementMode(sc.ELEMENT.NEUTRAL);
            this.postStun.choice =
                null;
            this.reactions.current = null;
            this.reactions.restartAction = null
        },
        update: function () {
            if (this.dodge.counterCooldownMax) {
                this.dodge.counterCooldown = this.dodge.counterCooldown + ig.system.tick;
                if (this.dodge.counterCooldown >= this.dodge.counterCooldownMax)
                    this.dodge.counterCooldownMax = this.dodge.counterCooldown = 0
            }
            if (this.dodge.timer > 0) {
                this.dodge.timer = this.dodge.timer - ig.system.tick;
                if (this.dodge.timer <= 0) {
                    this.dodge.timer = 0;
                    this.dodge.count = 0;
                    this.dodge.blocked = false
                }
            }
            this.ownerEnemy && (this.ownerEnemy.isDefeated() &&
                !this.isDefeated()) && this.instantDefeat();
            this.enemyType && !this.enemyTypeInitialized && this.enemyType.initEntity(this);
            if (this.enemyType && this.enemyType.isReadyToFight(this)) {
                this.targetFixed = false;
                for (var a in this.stateTimers)
                    this.stateTimers[a] = this.stateTimers[a] - ig.system.tick;
                for (a in this.trackers) {
                    var b = this.trackers[a];
                    b.update && b.update()
                }
                this.enemyType.update(this)
            } else
                this.targetFixed || this.setTarget(null);
            this.parent()
        },
        onTargetHit: function (a, b, d, g, h) {
            if (g == sc.SHIELD_RESULT.PERFECT &&
                !h.isBall) {
                a.combo && a.combo.guardTrapTime && this.setCounterCooldown();
                for (h = 0; h < this.reactions.enabled.length; ++h) {
                    var i = this.reactions.enabled[h],
                    j = this.enemyType.reactions[i];
                    if (j.type == "GUARD_COUNTER" && j.onGuardCounterCheck(this)) {
                        this.reactions.current = i;
                        j.onGuardCountered(this, a);
                        return true
                    }
                }
            }
            this.parent(a, b, d, g)
        },
        setCounterCooldown: function () {
            for (var a in this.enemyType.reactions) {
                var b = this.enemyType.reactions[a];
                if (b.type == "COUNTER_COUNTER") {
                    this.dodge.counterCooldownMax = b.cooldown;
                    this.dodge.counterCooldown =
                        0;
                    break
                }
            }
        },
        onFallBehavior: function (a) {
            for (var b = 0; b < this.reactions.enabled.length; ++b) {
                var d = this.reactions.enabled[b],
                g = this.enemyType.reactions[d];
                if (g.type == "FALL" && g.checkFall(a)) {
                    if (this.reactions.running == g)
                        return true;
                    g.onFall(this);
                    this.reactions.current = d;
                    return true
                }
            }
            return false
        },
        postActionUpdate: function () {
            this.enemyType && this.enemyType.isReadyToFight(this) && this.enemyType.postActionUpdate(this)
        },
        onStunEnd: function () {
            if (this.enemyType && this.enemyType.isReadyToFight(this))
                this.enemyType.onStunEnd(this)
        },
        changeState: function (a, b, d) {
            if (this.enemyType)
                if (b) {
                    this.cancelAction();
                    this.enemyType.initEntity(this);
                    this.enemyType.switchState(this, a)
                } else {
                    this.nextState = a;
                    d && this.enemyType.switchStateConfig(this, a)
                }
        },
        onPreDamageModification: function (a, d, f, g, h, i, j) {
            var k = false;
            b.damagingEntity = d;
            b.attackInfo = f;
            b.partEntity = g;
            b.damageResult = h;
            b.shielded = i;
            b.weakness = 0;
            b.dramaticEffect = null;
            f = Math.random();
            k = this._checkHitReactions(a, d, f, false);
            if (a.damageResult)
                h = a.damageResult;
            g = h && h.damage || 0;
            i = 0;
            b.killed =
                false;
            if (!j) {
                if (h && this.enemyType.resolveHpBreak(a, this, d.getCombatant(), h.damage)) {
                    i = this.hpBreakReached;
                    k = true
                }
                b.killed = this.params && this.params.currentHp > 0 && this.params.currentHp - g <= 0;
                b.killed && (i = 0)
            }
            b.hpBroken = i;
            k = this._checkHitReactions(a, d, f, true) || k;
            b.dramaticEffect && sc.combat.doDramaticEffect(d.getCombatantRoot(), this, b.dramaticEffect);
            b.killed && !a.survive && this._delegateDamage();
            return k
        },
        _delegateDamage: function () {
            if (this.hpAttached.enemy) {
                var a = Math.ceil(this.hpAttached.enemy.params.getStat("hp") *
                        this.hpAttached.value);
                this.hpAttached.enemy.instantDamage(a, 2, this);
                this.hpAttached.enemy = null
            }
        },
        onInstantDamage: function (a, d) {
            var f = 0;
            b.damagingEntity = ig.game.playerEntity;
            b.attackInfo = null;
            b.partEntity = null;
            b.damageResult = null;
            b.shielded = false;
            b.weakness = 0;
            b.dramaticEffect = null;
            if (this.enemyType.resolveHpBreak(null, this, ig.game.playerEntity, a, d))
                f = this.hpBreakReached;
            b.killed = this.params && this.params.currentHp > 0 && this.params.currentHp - a <= 0;
            b.killed && (f = 0);
            b.hpBroken = f;
            f = {
                survive: false
            };
            (b.killed ||
                b.hpBroken) && this._checkHitReactions(f, ig.game.playerEntity, Math.random(), true);
            b.dramaticEffect && sc.combat.doDramaticEffect(ig.game.playerEntity, d || this, b.dramaticEffect);
            b.killed && !f.survive && this._delegateDamage();
            return f.survive
        },
        _checkHitReactions: function (a, d, f, g) {
            for (var h = false, i = 0; i < this.reactions.enabled.length; ++i) {
                b.weakness = 0;
                var j = this.reactions.enabled[i],
                k = this.enemyType.reactions[j];
                if (k.type == "HIT_REACTION") {
                    var l = !k.needInterrupt();
                    if (g || l || !(k.hitType != sc.HIT_REACTION_TYPE.FORCE_HIT &&
                            this.reactions.current))
                        if (k.checkHit(this, f, b, a, g)) {
                            if (!l)
                                this.reactions.current = j;
                            k.hitApply(this, d, b, a, this.enemyType.actions);
                            if (b.weakness >= 1 && k.dramaticEffect) {
                                this.statusGui.clearStatusEntry("BREAK");
                                a.weakness = 0
                            }
                            h = true;
                            if (!l)
                                return true
                        } else {
                            if (b.weakness && k.dramaticEffect) {
                                k.partFocus ? this.statusGui.setReplaceTarget(ig.CollTools.getNamedSubCollEntity(this.coll, k.partFocus)) : this.statusGui.setReplaceTarget(null);
                                a.weakness = b.weakness
                            }
                            if (k.ignoreFailed && !b.weakness)
                                a.ignoreHit = true
                        }
                }
            }
            return h
        },
        collabReady: function (a) {
            for (var b = 0; b < this.reactions.enabled.length; ++b) {
                var d = this.enemyType.reactions[this.reactions.enabled[b]];
                if (d.type == "COLLAB" && d.isReady(this, a))
                    return true
            }
        },
        doCollabReaction: function (a) {
            if (!this.collaboration)
                throw Error("Tried to do collab reaction without collaboration set. Should never happen!");
            for (var b = 0; b < this.reactions.enabled.length; ++b) {
                var d = this.reactions.enabled[b],
                g = this.enemyType.reactions[d];
                if (g.type == "COLLAB" && g.collabKey == a) {
                    this.reactions.current = d;
                    this.enemyType.applyCurrentReaction(this);
                    break
                }
            }
        },
        getEnemyAction: function (a) {
            var b = this.enemyType.actions[a];
            if (!b)
                throw Error("Enemy does not has action of Name: " + a);
            return b
        },
        doEnemyAction: function (a, b, d) {
            var g = this.enemyType.actions[a];
            if (!g)
                throw Error("Enemy does not has action of Name: " + a);
            if (d) {
                if (!b) {
                    this.clearActionAttached();
                    this.defaultConfig.apply(this)
                }
                this.pushInlineAction(g)
            } else
                this.setAction(g, false, b)
        },
        onDamage: function (a, b, d) {
            (d = this.parent(a, b, d)) && !b.limiter.noAggro && !b.hasNoEffect() && this.enemyType && this.enemyType.damageUpdate(this,
                a);
            return d
        },
        onNavigationFailed: function (a) {
            sc.model.isForceCombat() || this.enemyType && this.enemyType.onNavigationFailed(this, a)
        },
        onDefeat: function (a) {
            this.defeatVarIncrease && ig.vars.add(this.defeatVarIncrease, 1);
            a || this.enemyType.resolveDefeat(this)
        },
        enableReactions: function (a) {
            if (a)
                for (var b = a.length; b--; ) {
                    var d = a[b];
                    if (this.reactions.enabled.indexOf(d) == -1)
                        this.enemyType.reactions[d].onActivate(this)
                }
            this.reactions.enabled.length = 0;
            a && this.reactions.enabled.push.apply(this.reactions.enabled, a)
        },
        enableReaction: function (a) {
            if (this.reactions.enabled.indexOf(a) == -1) {
                this.reactions.enabled.push(a);
                this.enemyType.reactions[a].onActivate(this)
            }
        },
        disableReaction: function (a) {
            a = this.reactions.enabled.indexOf(a);
            a != -1 && this.reactions.enabled.splice(a, 1)
        },
        onVarAccess: function (a, b) {
            return b[1] == "dodgeBlocked" ? this.dodge.blocked : b[1] == "hpBreak" ? this.hpBreakReached : b[1] == "level" ? this.getLevel() : b[1] == "storedEnemyCnt" ? this.storedEnemies.length : b[1] == "ownerAttrib" ? !this.ownerEnemy ? null : ig.vars.resolveObjectAccess(this.ownerEnemy.attributes,
                b, 2) : b[1] == "owner" ? !this.ownerEnemy ? null : ig.vars.forwardEntityVarAccess(this.ownerEnemy, b, 2) : b[1] == "collab" ? !this.collaboration ? null : this.collaboration.onVarAccess(a, b) : this.parent(a, b)
        }
    });
    ig.ACTOR_CONFIGS.ALLY = {
        classType: ig.ENTITY.Ally,
        KEYS: {
            enabledReactions: [],
            aggression: sc.ENEMY_AGGRESSION.THREAT,
            regenFactor: 0,
            stunEscapeTime: 0,
            annotate: {},
            size: Vec3.createC(16, 16, 16),
            analyzable: true,
            hpBar: sc.ENEMY_HP_BAR.AUTO
        },
        fromDataFix: function () {
            typeof this.aggression == "string" && (this.aggression = sc.ENEMY_AGGRESSION[this.aggression]);
            typeof this.hpBar == "string" && (this.hpBar = sc.ENEMY_HP_BAR[this.hpBar]);
            if (this.annotate) {
                var a = this.annotate;
                if (a.extra && a.extra instanceof Array) {
                    for (var b = a.extra, d = 0, g = 0; g < b.length; ++g)
                        d = d | sc.ENEMY_ANNO_EXTRA[b[g]];
                    a.extra = d
                }
                typeof a.active == "string" && (a.active = sc.ENEMY_ANNO_ACTIVE[a.active]);
                typeof a.passive == "string" && (a.passive = sc.ENEMY_ANNO_PASSIVE[a.passive]);
                typeof a.weapon == "string" && (a.weapon = sc.ENEMY_ANNO_WEAPON[a.weapon]);
                typeof a.element == "string" && (a.element = sc.ENEMY_ANNO_ELEMENT[a.element])
            } else
                this.annotate = {}
        },
        apply: function (a) {
            a.enableReactions(this.enabledReactions);
            if (a.aggression != this.aggression) {
                a.aggression = this.aggression;
                if (a.target) {
                    var b = a.target;
                    a.setTarget(null);
                    a.setTarget(b)
                }
            }
            a.visibility.analyzable = this.analyzable == void 0 ? true : this.analyzable;
            a.visibility.hpBar = this.hpBar;
            a.regenFactor = this.regenFactor;
            a.stunData.stunEscapeTime = this.stunEscapeTime || 0;
            a.annotate.active = this.annotate.active || 0;
            a.annotate.passive = this.annotate.passive || 0;
            a.annotate.weapon = this.annotate.weapon || 0;
            a.annotate.extra =
                this.annotate.extra || 0;
            a.annotate.element = this.annotate.element || 0;
            this.size && !window.wm && a.coll.setSize(this.size.x, this.size.y, this.size.z, true)
        },
        load: function (a) {
            this.enabledReactions = ig.copy(a.reactions.enabled);
            this.stunEscapeTime = a.stunData.stunEscapeTime;
            this.aggression = a.aggression;
            this.regenFactor = a.regenFactor;
            this.annotate = {
                active: a.annotate.active,
                passive: a.annotate.passive,
                weapon: a.annotate.weapon,
                extra: a.annotate.extra,
                element: a.annotate.element
            };
            this.analyzable = a.visibility.analyzable;
            this.hpBar = a.visibility.hpBar
        }
    };
    var a = new ig.Action("enemyStart", [{
                    type: "WAIT",
                    time: 0.4
                }
            ]),
    d = new ig.Action("enemyHide", [{
                    type: "SHOW_EFFECT",
                    effect: {
                        sheet: "teleport",
                        name: "hideDefault"
                    },
                    wait: true,
                    align: "CENTER"
                }, {
                    type: "HIDE"
                }
            ])
});
    ig.ACTION_STEP.SPAWN_ALLIES = ig.ActionStepBase.extend({
        forceSettings: null,
        enemyInfo: null,
        enemyType: null,
        _wm: new ig.Config({
            attributes: {
                enemyInfo: {
                    _type: "EnemyType",
                    _info: "Enemy information",
                    _popup: true
                },
                offset: {
                    _type: "Offset",
                    _info: "Offset relative to entity ground center from which to shoot"
                },
                align: {
                    _type: "String",
                    _info: "Alignment relative to entity from which to shoot",
                    _select: ig.ENTITY_ALIGN
                },
                dir: {
                    _type: "Vec2",
                    _info: "Direction to go to",
                    _actorOption: true,
                    _optional: true
                },
                pushVel: {
                    _type: "NumberVary",
                    _info: "If defined: push away enemies with given velocity",
                    _optional: true
                },
                pushZVel: {
                    _type: "NumberVary",
                    _info: "If defined: push away enemies with given z velocity",
                    _optional: true
                },
                centralAngle: {
                    _type: "Number",
                    _info: "Central angle of range. 1 = full circle"
                },
                startAngle: {
                    _type: "Number",
                    _info: "Angle from which to start. Default is - centralAngle / 2",
                    _optional: true
                },
                angleVary: {
                    _type: "Number",
                    _info: "Randomly vary each angle with the provided range"
                },
                startDist: {
                    _type: "Number",
                    _info: "Start Distance of ball in throw direction",
                    _optional: true
                },
                startDistCollide: {
                    _type: "String",
                    _info: "If not NONE: consider environment collision before adding start dist. CLOSER = move closer, DROP = Don't spawn if colliding",
                    _select: sc.SPAWN_START_DIST_COLLIDE
                },
                random: {
                    _type: "Boolean",
                    _info: "Spawn each Proxy in random direction within range"
                },
                count: {
                    _type: "NumberExpression",
                    _info: "The number of proxies thrown"
                },
                duration: {
                    _type: "Number",
                    _info: "Time it takes to throw proxies"
                },
                clockwise: {
                    _type: "Boolean",
                    _info: "If true throw proxies clockwise, otherwise counter clockwise"
                },
                flipLeftFace: {
                    _type: "Integer",
                    _info: "If FACE COUNT is provided: swap clockWise if face direction is towards left"
                },
                offsetArea: {
                    _type: "Vec2",
                    _info: "offset Area around position to randomly spawn entity at",
                    _optional: true
                },
                circularArea: {
                    _type: "Boolean",
                    _info: "Make offsetArea circular, not rectangular"
                },
                uniformDir: {
                    _type: "Number",
                    _info: "To what extend the final dir should be uniform. 1=all the same dir, 0= all individual, 0.5=between the two"
                },
                delay: {
                    _type: "Number",
                    _info: "Time delay for first shot"
                },
                repeat: {
                    _type: "Boolean",
                    _info: "If true, repeat proxy spawning until ended by force (action end or call STOP_REPEATING_FORCE)"
                },
                attachProxy: {
                    _type: "ProxyRef",
                    _info: "If defined: attach proxy to enemies",
                    _optional: true
                }
            }
        }),
        init: function (a) {
            this.forceSettings = ig.copy(a);
            if (a.enemyInfo)
                this.enemyInfo = new sc.EnemyInfo(a.enemyInfo);
            this.forceSettings.enemyType = this.enemyInfo.enemyType;
            a.attachProxy && (this.forceSettings.proxySrc = sc.ProxyTools.prepareSrc(a.attachProxy))
        },
        clearCached: function () {
            this.enemyInfo && this.enemyInfo.clearCached();
            this.forceSettings.proxySrc && sc.ProxyTools.releaseSrc(this.forceSettings.proxySrc)
        },
        start: function (a) {
            var b = new sc.AllySpawnerForce(a, this.forceSettings);
            sc.combat.addCombatForce(b);
            a.addActionAttached(b)
        }
    });
    sc.AllySpawnerForce = sc.CombatForce.extend({
        enemyInfo: null,
        enemyType: null,
        spawnHelper: null,
        timer: 0,
        spawnData: {},
        init: function (a, b) {
            this.parent(a);
            this.enemyType = b.enemyType;
            this.enemyInfo = b.enemyInfo;
            this.pushVel = b.pushVel;
            this.pushZVel = b.pushZVel;
            this.proxySrc = b.proxySrc;
            this.spawnHelper = new sc.SpawnHelper(b, this.spawnEnemy.bind(this));
            this.timer = this.spawnHelper.initData(this.spawnData)
        },
        update: function () {
            this.timer = this.spawnHelper.spawn(this.combatant, this.timer, this.spawnData);
            return this.timer <= 0
        },
        spawnEnemy: function (a, b, c, d) {
            var e = null;
            if (this.combatantRoot instanceof ig.ENTITY.Ally)
                e = this.combatantRoot;
            var f = ig.game.spawnEntity(ig.ENTITY.Ally, a - this.enemyType.size.x / 2, b - this.enemyType.size.y / 2, c, {
                enemyInfo: this.enemyInfo,
                ownerEnemy: e
            }, true);
            Vec2.assign(f.face, d);
            this.combatant.target ? f.setTarget(this.combatant.target, true) : f.enemyType.reselectTarget(f, false, true, true);
            if (this.pushVel) {
                Vec2.assign(f.coll.vel, d);
                Vec2.length(f.coll.vel, ig.Event.getNumberVary(this.pushVel));
                f.coll.friction.air = 0
            }
            if (this.pushZVel)
                f.coll.vel.z = ig.Event.getNumberVary(this.pushZVel);
            if (this.proxySrc) {
                var g = sc.ProxyTools.getProxy(this.proxySrc,
                        e);
                if (g)
                    g.spawn(a, b, c, e, d).target = f
            }
        },
        isRepeating: function () {
            return this.spawnHelper.repeat
        }
    });
    //changes the spawner force so that the player can "own" an enemy
sc.EnemySpawnerForce = sc.CombatForce.extend({
        enemyInfo: null,
        enemyType: null,
        spawnHelper: null,
        timer: 0,
        spawnData: {},
        init: function (a, b) {
            this.parent(a);
            this.enemyType = b.enemyType;
            this.enemyInfo = b.enemyInfo;
            this.pushVel = b.pushVel;
            this.pushZVel = b.pushZVel;
            this.proxySrc = b.proxySrc;
            this.spawnHelper = new sc.SpawnHelper(b, this.spawnEnemy.bind(this));
            this.timer = this.spawnHelper.initData(this.spawnData)
        },
        update: function () {
            this.timer = this.spawnHelper.spawn(this.combatant, this.timer, this.spawnData);
            return this.timer <= 0
        },
        spawnEnemy: function (a, b, c, d) {
            var e = null; // the said change is in this if condition
            if (this.combatantRoot instanceof ig.ENTITY.Enemy ||this.combatantRoot instanceof ig.ENTITY.Player)
                e = this.combatantRoot;
            var f = ig.game.spawnEntity(ig.ENTITY.Enemy, a - this.enemyType.size.x / 2, b - this.enemyType.size.y / 2, c, {
                enemyInfo: this.enemyInfo,
                ownerEnemy: e
            }, true);
            Vec2.assign(f.face, d);
            this.combatant.target ? f.setTarget(this.combatant.target, true) : f.enemyType.reselectTarget(f, false, true, true);
            if (this.pushVel) {
                Vec2.assign(f.coll.vel, d);
                Vec2.length(f.coll.vel, ig.Event.getNumberVary(this.pushVel));
                f.coll.friction.air = 0
            }
            if (this.pushZVel)
                f.coll.vel.z = ig.Event.getNumberVary(this.pushZVel);
            if (this.proxySrc) {
                var g = sc.ProxyTools.getProxy(this.proxySrc,
                        e);
                if (g)
                    g.spawn(a, b, c, e, d).target = f
            }
            if(this.enemyInfo.usePlayerRegen)
                f.usePlayerHpRegen = true;
            if(this.enemyInfo.usePlayerRegen15)
                f.usePlayerHpRegen15 = true;
            
        },
        isRepeating: function () {
            return this.spawnHelper.repeat
        }
    });
    
ig.ENTITY.Enemy.inject({
    update(){
        this.parent();
        if(this.usePlayerHpRegen) {
            this.regenFactor=sc.model.player.params.getModifier("HP_REGEN");
           }
           else if(this.usePlayerHpRegen15) {
            this.regenFactor=sc.model.player.params.getModifier("HP_REGEN") * 1.5;
           }
        }
});
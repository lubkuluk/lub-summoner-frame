ig.EVENT_STEP.START_PVP_BATTLE = ig.EventStepBase.extend({
    winPoints: 0,
    enemies: [],
    allies: [],  // Add allies as a property
    _wm: new ig.Config({
        attributes: {
            winPoints: {
                _type: "Integer",
                _info: "Number of points to win PVP battle"
            },
            enemies: {
                _type: "Array",
                _info: "List of all enemies that participate in battle",
                _sub: {
                    _type: "Entity"
                }
            },
            allies: {  // Define the optional allies attribute
                _type: "Array",
                _info: "List of all allies that participate in battle (optional)",
                _sub: {
                    _type: "Entity"
                },
                _optional: true  // Mark this attribute as optional
            }
        }
    }),
    init: function (a) {
        this.winPoints = a.winPoints;
        this.enemies = a.enemies || [];  // Initialize enemies, default to empty array if not provided
        this.allies = a.allies || [];    // Initialize allies, default to empty array if not provided
    },
    start: function (a, b) {
        var d = [];
        for (var g = 0; g < this.enemies.length; g++)
            d.push(ig.Event.getEntity(this.enemies[g], b));
        
        var f = [];
        for (var h = 0; h < this.allies.length; h++)
            f.push(ig.Event.getEntity(this.allies[h], b));
        
        sc.pvp.start(this.winPoints, d, f);  // Pass allies to the start method
    }
});
ig.EVENT_STEP.START_PVP_BATTLE_CUSTOM = ig.EventStepBase.extend({
    winPoints: 0,
    enemies: [],
    allies: [],  // Add allies as a property
    _wm: new ig.Config({
        attributes: {
            winPoints: {
                _type: "Integer",
                _info: "Number of points to win PVP battle"
            },
            enemies: {
                _type: "Array",
                _info: "List of all enemies that participate in battle",
                _sub: {
                    _type: "Entity"
                }
            },
            allies: {  // Define the optional allies attribute
                _type: "Array",
                _info: "List of all allies that participate in battle (optional)",
                _sub: {
                    _type: "Entity"
                },
                _optional: true  // Mark this attribute as optional
            }
        }
    }),
    init: function (a) {
        this.winPoints = a.winPoints;
        this.enemies = a.enemies || [];  // Initialize enemies, default to empty array if not provided
        this.allies = a.allies || [];    // Initialize allies, default to empty array if not provided
    },
    start: function (a, b) {
        var d = [];
        for (var g = 0; g < this.enemies.length; g++)
            d.push(ig.Event.getEntity(this.enemies[g], b));
        
        var f = [];
        for (var h = 0; h < this.allies.length; h++)
            f.push(ig.Event.getEntity(this.allies[h], b));
        
        sc.pvp.start(this.winPoints, d, f);  // Pass allies to the start method
    }
});
ig.EVENT_STEP.PVP_ENEMY_WIN = ig.EventStepBase.extend({
        _wm: new ig.Config({
            attributes: {}
        }),
        init: function () {},
        start: function () {
            sc.pvp.showKO(sc.COMBATANT_PARTY.ENEMY)
        }
});
ig.EVENT_STEP.PVP_PLAYER_WIN = ig.EventStepBase.extend({
    _wm: new ig.Config({
        attributes: {}
    }),
    init: function () {},
    start: function () {
        sc.pvp.showKO(sc.COMBATANT_PARTY.PLAYER)
    }
});

//Hello, Lubkuluk here, now let me explain what these event steps do, how you could use it and where
//These event steps' main use is to modify the pvp via map events which wanst possible befor
//By using my method you can successfully use enemies from the PLAYER party as an ally to fight alongside the player 
//
//First, you need to set the variable called "tmp.dualPvp" to true
//Second in your pvpBrake event (go to starting point do animation do side_msg etc) you need to set the startCondition of the event to a special tmp or map variable
// It's important that it is NOT ONLY pvp.brake or pvp.killHit or pvp.finalHit, this startCondition needs to be able to be called via a variable
//by using Krypek's code inside Xenon's Playable Classes mod, you can detect when a pvp entity has died regardless of party player or enemy
// now you need to have an event step that checks whether all allies have died, using a startCondition like pvp.brake || tmp.pvpBrake ensures you don't need to check enemies' death, as pvp.brake does that already
// the event step needs to turn on your custom variable when all the allies and the player dies, also make sure it increments a number each time it does so
// this way when the incremented number matches the amount of rounds set by START_PVP_BATTLE you would need to call pvpFinished event step
// keep in mind the pvpFinished event step's startCondition should be like pvpBrake's (for example pvp.finished || tmp.pvpFinished)
// hope this clears enough stuff up, if not message me in discord
//
// So to sum it up, when al the allies die, use the event step PVP_ENEMY_WIN turn on a condition to either do pvpBrake or pvpFinished event step depending on the rounds